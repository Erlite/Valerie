___________                           __  .__              ________               
\_   _____/__  ___ ____  ____ _______/  |_|__| ____   ____ \______ \   _______  __
 |    __)_\  \/  // ___\/ __ \\____ \   __\  |/  _ \ /    \ |    |  \_/ __ \  \/ /
 |        \>    <\  \__\  ___/|  |_> >  | |  (  <_> )   |  \|    `   \  ___/\   / 
/_______  /__/\_ \\___  >___  >   __/|__| |__|\____/|___|  /_______  /\___  >\_/  
        \/      \/    \/    \/|__|                       \/        \/     \/      

===================================================================================

- Current version = 7.4
- Release = Alpha
- All Commands = No (Some commands aren't working)
- Errors = Minimum
- Github = https://github.com/ExceptionDev/DiscordExampleBot
- DiscordName = ExceptionDev#6045
- Discord = https://discord.me/ArcaneOps
- Docs = https://exceptiondev.github.io/DiscordExampleBot/#/

- Do I need to read docs?
Have you worked with Visual Studio (VS) before? If yes, you don't need to read docs.
Else, you do need to read docs and learn C#. I'm not the master of C#.

- Nuget won't restore packages?
Did you read docs? It's explained there.

- I read the docs and followed the "New Console Application" but I can't install nuget packages?
I didn't design nuget or Visual Studio. If it's says meta data is unavailable please Google the error. Or join Discord API server.
